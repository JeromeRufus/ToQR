import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:http/http.dart' as http;
import 'dart:convert' as convert;

class LocationService {
  String url = 'AIzaSyA_VD1x7qwIvJrmu_tPDnI9XBUq3_D4ws0';

  /*String url =
      'https://maps.googleapis.com/maps/api/directions/json?origin=LAT,LON&destination=LAT,LON&key=API_KEY';*/
}
