import 'dart:ui';

class AppColors{
  static final Color textColor1= Color(0XFF989acd);
  static final Color mainColor=Color(0xFF5d69b3);
}